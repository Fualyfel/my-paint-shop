package model;
/**
 * TBD.
 * @author Fawaz
 *
 */
public class IllegalValueException extends Exception {

}
